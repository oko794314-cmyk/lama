using UnityEngine;

// Игрок: ходьба от 3-го лица, прыжок, спринт, карабканье по горам (тег Climbable).
// Управление: WASD + мышь (обзор), Space прыжок, Shift спринт,
// E сесть/слезть с ламы, ЛКМ/Q плевок (когда верхом), W+Space у стены = лезть.
[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    [Header("Движение")]
    public float walkSpeed = 5f;
    public float sprintSpeed = 8f;
    public float jumpForce = 7f;
    public float gravity = -22f;
    public float turnSmooth = 12f;

    [Header("Карабканье")]
    public float climbSpeed = 3.2f;
    public float climbCheckDist = 1.2f;
    public LayerMask climbMask = ~0;

    [Header("Камера")]
    public float camDistance = 6.5f;
    public float camHeight = 2.2f;
    public float mouseSens = 2.5f;

    [Header("Состояние")]
    public bool isRiding;
    public LlamaMount currentLlama;
    public int health = 100;

    CharacterController cc;
    Vector3 vel;
    float yaw, pitch = 12f;
    bool climbing;
    Transform cam;
    float spitCd;

    void Awake()
    {
        cc = GetComponent<CharacterController>();
        if (cc.height < 1.2f) { cc.height = 1.8f; cc.center = new Vector3(0, 0.9f, 0); }
        cc.skinWidth = 0.08f;
        cc.minMoveDistance = 0.001f;
    }

    void Start()
    {
        var c = Camera.main;
        if (c != null) cam = c.transform;
        yaw = transform.eulerAngles.y;
    }

    void Update()
    {
        if (cam == null)
        {
            var c = Camera.main;
            if (c != null) cam = c.transform;
        }

        HandleMouse();
        // Сесть / слезть
        if (Input.GetKeyDown(KeyCode.E))
        {
            if (isRiding) Dismount();
            else TryMount();
        }

        if (isRiding && currentLlama != null)
        {
            // Камеру ведём за ламой, игрок сидит
            FollowCam(currentLlama.transform);
            // Плевок верхом
            spitCd -= Time.deltaTime;
            if ((Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Q)) && spitCd <= 0f)
            {
                currentLlama.Spit();
                spitCd = 0.8f;
            }
            return;
        }

        // Пеший плевок тоже разрешим (слабый бросок камня? нет — только верхом).
        // Проверка карабканья
        UpdateClimbState();

        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");
        bool sprint = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
        float speed = sprint ? sprintSpeed : walkSpeed;

        // Направление относительно камеры
        Vector3 fwd = cam != null ? cam.forward : transform.forward;
        fwd.y = 0; fwd.Normalize();
        Vector3 right = cam != null ? cam.right : Vector3.right;
        right.y = 0; right.Normalize();

        Vector3 move = (right * h + fwd * v);
        if (move.sqrMagnitude > 1f) move.Normalize();

        if (climbing)
        {
            // Лезем вверх/вниз по стене: W вверх, S вниз, A/D сдвиг
            Vector3 up = Vector3.up * v * climbSpeed;
            Vector3 side = right * h * climbSpeed * 0.6f;
            cc.Move((up + side) * Time.deltaTime);
            vel.y = 0;
            if (Input.GetKeyDown(KeyCode.Space))
            {
                // Спрыгнуть от стены
                climbing = false;
                vel.y = jumpForce * 0.8f;
                cc.Move(-fwd * 0.6f);
            }
            if (move.sqrMagnitude > 0.01f)
            {
                Quaternion look = Quaternion.LookAtRotation(fwd);
                transform.rotation = Quaternion.Slerp(transform.rotation, look, Time.deltaTime * turnSmooth);
            }
            FollowCam(transform);
            return;
        }

        if (cc.isGrounded)
        {
            if (vel.y < 0) vel.y = -2f;
            if (Input.GetKeyDown(KeyCode.Space))
                vel.y = jumpForce;
        }
        vel.y += gravity * Time.deltaTime;

        Vector3 m = move * speed + new Vector3(0, vel.y, 0);
        cc.Move(m * Time.deltaTime);

        if (move.sqrMagnitude > 0.01f)
        {
            Quaternion look = Quaternion.LookAtRotation(move);
            transform.rotation = Quaternion.Slerp(transform.rotation, look, Time.deltaTime * turnSmooth);
        }
        FollowCam(transform);
    }

    void UpdateClimbState()
    {
        if (cc.isGrounded) { if (!Input.GetKey(KeyCode.W)) climbing = false; }
        // Луч вперёд на уровне груди
        Vector3 origin = transform.position + Vector3.up * 1.4f;
        bool hitWall = Physics.Raycast(origin, transform.forward, climbCheckDist, climbMask);
        if (!hitWall)
            hitWall = Physics.Raycast(transform.position + Vector3.up * 0.6f, transform.forward, climbCheckDist, climbMask);
        // Лезем только если впереди объект с тегом Climbable (или слой гор)
        if (hitWall)
        {
            RaycastHit h1;
            if (Physics.Raycast(origin, transform.forward, out h1, climbCheckDist + 0.3f))
            {
                // Тег Climbable может отсутствовать в проекте — проверяем и по имени, чтобы не падать с ошибкой.
                bool climbable = false;
                if (h1.collider != null)
                {
                    try { climbable = h1.collider.CompareTag("Climbable"); } catch { climbable = false; }
                    if (!climbable) climbable = h1.collider.name.Contains("Climb");
                }
                if (climbable)
                {
                    if (Input.GetKey(KeyCode.W) && !cc.isGrounded)
                        climbing = true;
                    else if (Input.GetKey(KeyCode.W) && Input.GetKey(KeyCode.Space))
                        climbing = true; // старт с земли
                }
                else if (h1.collider != null && Input.GetKey(KeyCode.W) && Input.GetKey(KeyCode.Space))
                {
                    // По горам (Mountain*) тоже даём лезть, но медленнее — как в PEAK
                    if (h1.collider.name.Contains("Mountain") || h1.collider.name.Contains("Tier") || h1.collider.name.Contains("Ledge"))
                        climbing = true;
                }
            }
        }
        else climbing = false;
    }

    void TryMount()
    {
        var llamas = FindObjectsByType<LlamaMount>(FindObjectsSortMode.None);
        LlamaMount best = null; float bd = 3.2f;
        foreach (var l in llamas)
        {
            float d = Vector3.Distance(l.mountPoint.position, transform.position);
            if (d < bd) { bd = d; best = l; }
        }
        if (best != null) Mount(best);
    }

    public void Mount(LlamaMount llama)
    {
        currentLlama = llama;
        isRiding = true;
        llama.Rider = this;
        cc.enabled = false;
        // Посадить на седло
        transform.SetParent(llama.mountPoint);
        transform.localPosition = Vector3.zero;
        transform.localRotation = Quaternion.identity;
    }

    public void Dismount()
    {
        if (currentLlama == null) { isRiding = false; return; }
        transform.SetParent(null);
        Vector3 side = currentLlama.transform.right * 1.6f;
        transform.position = currentLlama.transform.position + side + Vector3.up * 1f;
        cc.enabled = true;
        vel = Vector3.zero;
        currentLlama.Rider = null;
        currentLlama = null;
        isRiding = false;
    }

    void HandleMouse()
    {
        if (Input.GetMouseButton(1) || Input.GetKey(KeyCode.LeftAlt) == false)
        {
            // Свободный обзор мышью всегда (без удержания) — как в шутерах от 3 лица
            yaw += Input.GetAxis("Mouse X") * mouseSens;
            pitch -= Input.GetAxis("Mouse Y") * mouseSens * 0.7f;
            pitch = Mathf.Clamp(pitch, -10f, 60f);
        }
    }

    void FollowCam(Transform target)
    {
        if (cam == null) return;
        Quaternion rot = Quaternion.Euler(pitch, yaw, 0);
        Vector3 pivot = target.position + Vector3.up * camHeight;
        Vector3 want = pivot - rot * Vector3.forward * camDistance;
        // Чтобы камера не уходила в скалы
        RaycastHit hit;
        if (Physics.Linecast(pivot, want, out hit))
            want = hit.point + hit.normal * 0.3f;
        cam.position = Vector3.Lerp(cam.position, want, Time.deltaTime * 10f);
        cam.rotation = rot;
    }

    public void Damage(int dmg)
    {
        health -= dmg;
        if (health <= 0)
        {
            health = 100;
            // Респаун на спавне
            var s = GameObject.Find("PlayerSpawn");
            if (s != null) { transform.position = s.transform.position + Vector3.up * 1f; vel = Vector3.zero; }
            else transform.position = new Vector3(0, 5, -38);
        }
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawRay(transform.position + Vector3.up * 1.4f, transform.forward * climbCheckDist);
    }
}
