using UnityEngine;

// Точка входа игры: генерирует данж, горы, растительность, спавнит игрока и ламу.
// Как пользоваться:
//  1. Открой сцену DesertMap, нажми Play — всё появится само (autoGenerateOnStart).
//  2. Или повесь этот скрипт на пустой GameObject "Game" и нажми Play.
// Управление: WASD движение, мышь обзор, Space прыжок, Shift бег,
// E сесть/слезть с ламы и открыть сундук, ЛКМ/Q плевок верхом,
// W+Space у оранжевой стены — карабкаться.
[DefaultExecutionOrder(10)]
public class GameBootstrap : MonoBehaviour
{
    [Header("Автогенерация")]
    public bool generateDungeon = true;
    public bool generateMountains = true;
    public bool generateVegetation = true;
    public bool spawnPlayerAndLlama = true;
    public int seed = 1337;

    [Header("Спавн")]
    public Vector3 llamaOffset = new Vector3(2.5f, 1f, 0);

    void Start()
    {
        // 0) Убедимся что карта пустыни есть
        var desert = FindFirstObjectByType<DesertMapGenerator>();
        if (desert == null)
        {
            var g = new GameObject("DesertMapGenerator");
            desert = g.AddComponent<DesertMapGenerator>();
            desert.seed = seed;
        }
        // Если рута нет — сгенерировать
        if (GameObject.Find("DesertMap_Root") == null)
            desert.Generate();

        FixDesertPhysics();

        // 1) Данж
        if (generateDungeon)
        {
            var d = FindFirstObjectByType<DungeonGenerator>();
            if (d == null) d = new GameObject("Dungeon").AddComponent<DungeonGenerator>();
            d.Generate();
        }

        // 2) Горы (после пустыни, чтобы рейкасты растительности видели скалы)
        if (generateMountains)
        {
            var m = FindFirstObjectByType<MountainBiomeGenerator>();
            if (m == null) m = new GameObject("Mountains").AddComponent<MountainBiomeGenerator>();
            m.Generate();
        }

        // 3) Растительность
        if (generateVegetation)
        {
            var v = FindFirstObjectByType<VegetationGenerator>();
            if (v == null) v = new GameObject("Vegetation").AddComponent<VegetationGenerator>();
            v.Generate();
        }

        // 4) Игрок + лама
        if (spawnPlayerAndLlama)
            SpawnPlayerAndLlama();

        // 5) Камера по умолчанию
        SetupCamera();
    }

    void FixDesertPhysics()
    {
        // Земля: убедимся что есть коллайдер (у Plane-примитива он уже есть).
        // Д près: включаем коллайдеры обратно там где они важны для геймплея:
        // пальмы-стволы, кактусы, скалы, колонны — оставляем как есть (у примитивов коллайдеры уже есть),
        // а у дюн/дорог/листьев они выключены в генераторе — так и надо (не мешают бегать).
        // Дополнительно: у Terrain (если сцена из Builder) проверим TerrainCollider.
        var t = FindFirstObjectByType<Terrain>();
        if (t != null && t.GetComponent<TerrainCollider>() == null)
            t.gameObject.AddComponent<TerrainCollider>();
        Physics.gravity = new Vector3(0, -22f, 0);
    }

    void SpawnPlayerAndLlama()
    {
        Vector3 spawn = new Vector3(0, 3f, -38);
        var sp = GameObject.Find("PlayerSpawn");
        if (sp != null) spawn = sp.transform.position + Vector3.up * 1f;

        // Игрок
        var pc = FindFirstObjectByType<PlayerController>();
        GameObject player;
        if (pc == null)
        {
            player = new GameObject("Player");
            player.transform.position = spawn;
            var cc = player.AddComponent<CharacterController>();
            cc.height = 1.8f; cc.radius = 0.35f; cc.center = new Vector3(0, 0.9f, 0);
            player.AddComponent<PlayerController>();
            var s = Shader.Find("Universal Render Pipeline/Lit");
            if (s == null) s = Shader.Find("Standard");
            Material skin = new Material(s); skin.color = new Color(0.95f, 0.78f, 0.62f);
            Material shirt = new Material(s); shirt.color = new Color(0.25f, 0.5f, 0.75f);
            Material pants = new Material(s); pants.color = new Color(0.35f, 0.3f, 0.25f);
            Material pack = new Material(s); pack.color = new Color(0.6f, 0.42f, 0.25f);
            PlayerModelBuilder.Build(player.transform, skin, shirt, pants, pack);
        }
        else player = pc.gameObject;

        // Лама рядом
        var llama = FindFirstObjectByType<LlamaMount>();
        if (llama == null)
        {
            var lgo = new GameObject("Llama");
            lgo.transform.position = spawn + llamaOffset;
            lgo.AddComponent<CharacterController>();
            lgo.AddComponent<LlamaMount>();
        }
    }

    void SetupCamera()
    {
        var c = Camera.main;
        if (c == null)
        {
            var g = new GameObject("Main Camera");
            g.tag = "MainCamera";
            c = g.AddComponent<Camera>();
            c.farClipPlane = 2000;
            g.AddComponent<AudioListener>();
        }
        // Стартовый ракурс
        var pc = FindFirstObjectByType<PlayerController>();
        if (pc != null)
        {
            c.transform.position = pc.transform.position + new Vector3(0, 4, -8);
            c.transform.LookAt(pc.transform.position + Vector3.up * 1.5f);
        }
    }

    void OnGUI()
    {
        DungeonHUD.GUI();
        // Подсказка управления снизу
        var st = new GUIStyle(GUI.skin.box);
        st.fontSize = 13; st.alignment = TextAnchor.MiddleLeft;
        string ride = "";
        var pc = FindFirstObjectByType<PlayerController>();
        if (pc != null && pc.isRiding) ride = " | Верхрм: Shift галоп, ЛКМ/Q плевок, E слезть";
        string txt = "WASD идти • Мышь обзор • Space прыжок • Shift бег • E лама/сундук" + ride + " • W+Space у оранжевой стены — лезть • Данж: восток (60,-70)";
        GUI.Box(new Rect(10, Screen.height - 34, Mathf.Min(Screen.width - 20, 1020), 26), txt, st);
        // Прицел для плевка
        if (pc != null && pc.isRiding)
        {
            GUI.Label(new Rect(Screen.width / 2 - 8, Screen.height / 2 - 10, 20, 20), "+");
        }
    }
}
