using UnityEngine;

// Больше растительности: трава, агавы, цветы у оазиса, сухие деревья в переходе, кусты.
// Мелкая трава — без коллайдеров (производительность), деревья/агавы — с коллайдерами.
public class VegetationGenerator : MonoBehaviour
{
    Transform root;
    Material grassTuft, agave, flowerA, flowerB, dryWood, leafGreen, pineLeaf;

    public void Generate(int seed = 2026, int grassCount = 220, int agaveCount = 26, int flowerCount = 60)
    {
        var old = GameObject.Find("Vegetation_Root");
        if (old != null) DestroyImmediate(old);
        root = new GameObject("Vegetation_Root").transform;
        var rng = new System.Random(seed);

        var s = Shader.Find("Universal Render Pipeline/Lit");
        if (s == null) s = Shader.Find("Standard");
        grassTuft = M(s, "GrassTuft", new Color(0.45f, 0.62f, 0.3f));
        agave = M(s, "Agave", new Color(0.3f, 0.55f, 0.5f));
        flowerA = M(s, "FlowerA", new Color(0.95f, 0.35f, 0.45f));
        flowerB = M(s, "FlowerB", new Color(0.95f, 0.85f, 0.3f));
        dryWood = M(s, "DryWood", new Color(0.5f, 0.38f, 0.24f));
        leafGreen = M(s, "BushLeaf", new Color(0.28f, 0.55f, 0.26f));
        pineLeaf = M(s, "VegPine", new Color(0.2f, 0.42f, 0.24f));

        Vector3 oasis = new Vector3(0, 0, 15);

        // 1) Трава пучками по всей пустыне (гуще у воды)
        for (int i = 0; i < grassCount; i++)
        {
            Vector3 p;
            if (i % 3 == 0) p = oasis + new Vector3(Rand(rng, -14, 14), 0, Rand(rng, -14, 14));
            else p = new Vector3(Rand(rng, -95, 95), 0, Rand(rng, -95, 95));
            if (Vector3.Distance(p, oasis) < 6f && i % 3 != 0) continue;
            var tuft = new GameObject($"Grass_{i}");
            tuft.transform.SetParent(root, false);
            tuft.transform.position = Ground(p);
            tuft.transform.rotation = Quaternion.Euler(0, Rand(rng, 0, 360), 0);
            float sc = Rand(rng, 0.5f, 1.2f);
            for (int b = 0; b < 3; b++)
            {
                var blade = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                blade.name = "Blade";
                blade.transform.SetParent(tuft.transform, false);
                blade.transform.localPosition = new Vector3(Rand(rng, -0.3f, 0.3f), 0.35f * sc, Rand(rng, -0.3f, 0.3f));
                blade.transform.localRotation = Quaternion.Euler(Rand(rng, -14, 14), 0, Rand(rng, -14, 14));
                blade.transform.localScale = new Vector3(0.12f * sc, 0.4f * sc, 0.12f * sc);
                blade.GetComponent<Renderer>().sharedMaterial = grassTuft;
                blade.GetComponent<CapsuleCollider>().enabled = false;
            }
        }

        // 2) Агавы (колючие розетки) — с коллайдером-коробкой
        for (int i = 0; i < agaveCount; i++)
        {
            Vector3 p = new Vector3(Rand(rng, -90, 90), 0, Rand(rng, -90, 90));
            if (Vector3.Distance(p, oasis) < 14f) continue;
            var a = new GameObject($"Agave_{i}");
            a.transform.SetParent(root, false);
            a.transform.position = Ground(p);
            for (int l = 0; l < 7; l++)
            {
                float ang = l / 7f * 360f;
                var leaf = GameObject.CreatePrimitive(PrimitiveType.Cube);
                leaf.transform.SetParent(a.transform, false);
                leaf.transform.localPosition = new Vector3(Mathf.Cos(ang * Mathf.Deg2Rad) * 0.5f, 0.35f, Mathf.Sin(ang * Mathf.Deg2Rad) * 0.5f);
                leaf.transform.localScale = new Vector3(0.28f, 0.18f, 1.1f);
                leaf.transform.localRotation = Quaternion.Euler(-22, -ang, 0);
                leaf.GetComponent<Renderer>().sharedMaterial = agave;
            }
            var col = a.AddComponent<BoxCollider>();
            col.size = new Vector3(1.6f, 1f, 1.6f);
            col.center = new Vector3(0, 0.5f, 0);
        }

        // 3) Цветы у оазиса
        for (int i = 0; i < flowerCount; i++)
        {
            float ang = Rand(rng, 0, 360);
            float r = Rand(rng, 6f, 13f);
            Vector3 p = oasis + new Vector3(Mathf.Cos(ang * Mathf.Deg2Rad) * r, 0, Mathf.Sin(ang * Mathf.Deg2Rad) * r);
            var f = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            f.name = $"Flower_{i}";
            f.transform.SetParent(root, false);
            f.transform.position = Ground(p) + Vector3.up * 0.35f;
            f.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
            f.GetComponent<Renderer>().sharedMaterial = (i % 2 == 0) ? flowerA : flowerB;
            f.GetComponent<SphereCollider>().enabled = false;
            // стебель
            var st = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            st.transform.SetParent(root, false);
            st.transform.position = f.transform.position - Vector3.up * 0.2f;
            st.transform.localScale = new Vector3(0.07f, 0.2f, 0.07f);
            st.GetComponent<Renderer>().sharedMaterial = grassTuft;
            st.GetComponent<CapsuleCollider>().enabled = false;
        }

        // 4) Сухие деревья в полосе перехода (z 60..110) — с коллайдерами ствола
        for (int i = 0; i < 18; i++)
        {
            Vector3 p = new Vector3(Rand(rng, -100, 100), 0, Rand(rng, 55, 115));
            BuildDryTree(Ground(p), Rand(rng, 0.8f, 1.4f), i);
        }

        // 5) Кусты цветущие у воды + обычные
        for (int i = 0; i < 24; i++)
        {
            Vector3 p = (i < 12)
                ? oasis + new Vector3(Rand(rng, -12, 12), 0, Rand(rng, -12, 12))
                : new Vector3(Rand(rng, -90, 90), 0, Rand(rng, -90, 90));
            var b = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            b.name = $"Bush_{i}";
            b.transform.SetParent(root, false);
            b.transform.position = Ground(p) + Vector3.up * 0.5f;
            float bs = Rand(rng, 0.7f, 1.6f);
            b.transform.localScale = new Vector3(bs, bs * 0.75f, bs);
            b.GetComponent<Renderer>().sharedMaterial = leafGreen;
            // У кустов оставляем коллайдер, чтобы была физика, но маленьким не мешаем
            if (bs > 1.2f) b.GetComponent<SphereCollider>().radius = 0.5f;
            else b.GetComponent<SphereCollider>().enabled = false;
        }
    }

    void BuildDryTree(Vector3 p, float s, int idx)
    {
        var t = new GameObject($"DryTree_{idx}");
        t.transform.SetParent(root, false);
        t.transform.position = p;
        t.transform.rotation = Quaternion.Euler(0, idx * 47f, 0);
        var trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        trunk.transform.SetParent(t.transform, false);
        trunk.transform.localPosition = new Vector3(0, 1.6f * s, 0);
        trunk.transform.localScale = new Vector3(0.4f * s, 1.6f * s, 0.4f * s);
        trunk.GetComponent<Renderer>().sharedMaterial = dryWood;
        for (int b = 0; b < 3; b++)
        {
            var br = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            br.transform.SetParent(t.transform, false);
            br.transform.localPosition = new Vector3(0.5f * s, (2.2f + b * 0.5f) * s, 0);
            br.transform.localRotation = Quaternion.Euler(0, 0, -55 - b * 12);
            br.transform.localScale = new Vector3(0.18f * s, 0.9f * s, 0.18f * s);
            br.GetComponent<Renderer>().sharedMaterial = dryWood;
            br.GetComponent<CapsuleCollider>().enabled = false;
        }
        // редкие листья наверху
        var top = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        top.transform.SetParent(t.transform, false);
        top.transform.localPosition = new Vector3(0, 3.4f * s, 0);
        top.transform.localScale = new Vector3(1.4f * s, 0.9f * s, 1.4f * s);
        top.GetComponent<Renderer>().sharedMaterial = pineLeaf;
        top.GetComponent<SphereCollider>().enabled = false;
    }

    Vector3 Ground(Vector3 p)
    {
        RaycastHit hit;
        if (Physics.Raycast(new Vector3(p.x, 60, p.z), Vector3.down, out hit, 130))
        {
            // Не сажаем внутрь скал/построек: если попали в проп — всё равно ставим чуть выше
            return hit.point;
        }
        return new Vector3(p.x, 0, p.z);
    }

    Material M(Shader s, string n, Color c)
    {
        var m = new Material(s); m.name = n; m.color = c;
        return m;
    }
    static float Rand(System.Random r, float a, float b) => (float)(a + r.NextDouble() * (b - a));
}
