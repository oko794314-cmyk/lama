using UnityEngine;

// Строит мультяшного игрока из примитивов: тело, голова, руки, ноги, рюкзак.
// Без внешних ассетов — всё процедурой, с коллизией через CharacterController родителя.
public static class PlayerModelBuilder
{
    public static GameObject Build(Transform parent, Material skin, Material shirt, Material pants, Material pack)
    {
        var root = new GameObject("PlayerModel");
        root.transform.SetParent(parent, false);
        root.transform.localPosition = Vector3.zero;

        // Тело
        var body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        body.name = "Body";
        body.transform.SetParent(root.transform, false);
        body.transform.localPosition = new Vector3(0, 1.05f, 0);
        body.transform.localScale = new Vector3(0.62f, 0.75f, 0.62f);
        body.GetComponent<Renderer>().sharedMaterial = shirt;
        Object.Destroy(body.GetComponent<Collider>()); // коллизия только на CharacterController

        // Голова
        var head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        head.name = "Head";
        head.transform.SetParent(root.transform, false);
        head.transform.localPosition = new Vector3(0, 1.85f, 0);
        head.transform.localScale = Vector3.one * 0.5f;
        head.GetComponent<Renderer>().sharedMaterial = skin;
        Object.Destroy(head.GetComponent<Collider>());

        // Шляпа путешественника (диск + купол)
        var brim = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        brim.name = "HatBrim";
        brim.transform.SetParent(root.transform, false);
        brim.transform.localPosition = new Vector3(0, 2.02f, 0);
        brim.transform.localScale = new Vector3(0.85f, 0.08f, 0.85f);
        brim.GetComponent<Renderer>().sharedMaterial = pack;
        Object.Destroy(brim.GetComponent<Collider>());

        var top = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        top.name = "HatTop";
        top.transform.SetParent(root.transform, false);
        top.transform.localPosition = new Vector3(0, 2.1f, 0);
        top.transform.localScale = new Vector3(0.45f, 0.3f, 0.45f);
        top.GetComponent<Renderer>().sharedMaterial = pack;
        Object.Destroy(top.GetComponent<Collider>());

        // Глаза
        for (int i = -1; i <= 1; i += 2)
        {
            var eye = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            eye.name = "Eye";
            eye.transform.SetParent(root.transform, false);
            eye.transform.localPosition = new Vector3(i * 0.11f, 1.88f, 0.22f);
            eye.transform.localScale = Vector3.one * 0.09f;
            eye.GetComponent<Renderer>().sharedMaterial = DarkMat();
            Object.Destroy(eye.GetComponent<Collider>());
        }

        // Руки
        for (int i = -1; i <= 1; i += 2)
        {
            var arm = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            arm.name = i < 0 ? "Arm_L" : "Arm_R";
            arm.transform.SetParent(root.transform, false);
            arm.transform.localPosition = new Vector3(i * 0.42f, 1.1f, 0);
            arm.transform.localScale = new Vector3(0.28f, 0.55f, 0.28f);
            arm.GetComponent<Renderer>().sharedMaterial = shirt;
            Object.Destroy(arm.GetComponent<Collider>());
        }

        // Ноги
        for (int i = -1; i <= 1; i += 2)
        {
            var leg = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            leg.name = i < 0 ? "Leg_L" : "Leg_R";
            leg.transform.SetParent(root.transform, false);
            leg.transform.localPosition = new Vector3(i * 0.16f, 0.35f, 0);
            leg.transform.localScale = new Vector3(0.3f, 0.42f, 0.3f);
            leg.GetComponent<Renderer>().sharedMaterial = pants;
            Object.Destroy(leg.GetComponent<Collider>());
        }

        // Рюкзак
        var bag = GameObject.CreatePrimitive(PrimitiveType.Cube);
        bag.name = "Backpack";
        bag.transform.SetParent(root.transform, false);
        bag.transform.localPosition = new Vector3(0, 1.15f, -0.38f);
        bag.transform.localScale = new Vector3(0.45f, 0.6f, 0.28f);
        bag.GetComponent<Renderer>().sharedMaterial = pack;
        Object.Destroy(bag.GetComponent<Collider>());

        return root;
    }

    static Material dark;
    static Material DarkMat()
    {
        if (dark == null)
        {
            var s = Shader.Find("Universal Render Pipeline/Lit");
            if (s == null) s = Shader.Find("Standard");
            dark = new Material(s);
            dark.color = Color.black;
        }
        return dark;
    }
}
