using UnityEngine;

// Горный биом на севере карты (z > 90): переход пустыня -> предгорья -> скалы.
// Горы — ступенчатые (террасы), по ним можно подняться: уступы + стены Climbable.
// Всё из примитивов, у всего есть коллайдеры.
public class MountainBiomeGenerator : MonoBehaviour
{
    [Header("Границы")]
    public float hillsStartZ = 80f;
    public float mountainStartZ = 140f;

    Transform root;
    Material rock, rockDark, snow, grass, pineLeaf, pineTrunk, climbMat;

    public void Generate(int seed = 777)
    {
        var old = GameObject.Find("Mountain_Root");
        if (old != null) DestroyImmediate(old);
        root = new GameObject("Mountain_Root").transform;
        var rng = new System.Random(seed);

        var s = Shader.Find("Universal Render Pipeline/Lit");
        if (s == null) s = Shader.Find("Standard");
        rock = Mat(s, "MtnRock", new Color(0.5f, 0.47f, 0.44f));
        rockDark = Mat(s, "MtnDark", new Color(0.36f, 0.33f, 0.31f));
        snow = Mat(s, "Snow", new Color(0.93f, 0.95f, 1f), 0f, 0.6f);
        grass = Mat(s, "MtnGrass", new Color(0.35f, 0.55f, 0.3f));
        pineLeaf = Mat(s, "Pine", new Color(0.16f, 0.38f, 0.22f));
        pineTrunk = Mat(s, "PineTrunk", new Color(0.35f, 0.24f, 0.14f));
        climbMat = Mat(s, "Climbable", new Color(0.75f, 0.5f, 0.25f));
        climbMat.EnableKeyword("_EMISSION");
        climbMat.SetColor("_EmissionColor", new Color(0.3f, 0.18f, 0.05f));

        // Переходная полоса: пятна травы и камней
        for (int i = 0; i < 40; i++)
        {
            float x = Rand(rng, -110, 110);
            float z = Rand(rng, hillsStartZ - 10, mountainStartZ + 10);
            var patch = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            patch.name = "TransitionPatch";
            patch.transform.SetParent(root, false);
            patch.transform.position = new Vector3(x, 0.12f, z);
            patch.transform.localScale = new Vector3(Rand(rng, 3, 8), 0.15f, Rand(rng, 3, 8));
            patch.GetComponent<Renderer>().sharedMaterial = (z < 110) ? grass : rockDark;
            patch.GetComponent<Collider>().enabled = false;
        }

        // Предгорья: холмы
        for (int i = 0; i < 10; i++)
        {
            Vector3 p = new Vector3(Rand(rng, -100, 100), 0, Rand(rng, hillsStartZ, mountainStartZ));
            if (Mathf.Abs(p.x) < 8 && p.z < 110) continue; // держим тропу от оазиса
            var hill = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            hill.name = $"Hill_{i}";
            hill.transform.SetParent(root, false);
            hill.transform.position = new Vector3(p.x, -1.2f, p.z);
            hill.transform.localScale = new Vector3(Rand(rng, 12, 22), Rand(rng, 2.5f, 5), Rand(rng, 10, 18));
            hill.GetComponent<Renderer>().sharedMaterial = (i % 2 == 0) ? grass : rock;
            hill.GetComponent<SphereCollider>().enabled = true;
        }

        // Главные горы: 6 ступенчатых пиков
        Vector3[] peaks = {
            new Vector3(-70, 0, 175), new Vector3(-25, 0, 190),
            new Vector3(20, 0, 180), new Vector3(65, 0, 195),
            new Vector3(-45, 0, 220), new Vector3(40, 0, 225),
        };
        foreach (var pk in peaks)
            BuildSteppedMountain(pk, rng);

        // Тропа наверх: серпантин уступов от пустыни к вершине (гарантированный подъём)
        BuildClimbTrail(new Vector3(0, 0, 100), new Vector3(20, 0, 180), rng);

        // Сосновый лес на склонах
        for (int i = 0; i < 60; i++)
        {
            Vector3 p = new Vector3(Rand(rng, -110, 110), 0, Rand(rng, 100, 230));
            BuildPine(p, Rand(rng, 0.8f, 1.6f));
        }

        // Смотровая площадка на вершине главной горы + флаг
        BuildSummit(new Vector3(20, 0, 180));

        // Невидимые границы карты, чтобы не падать
        Wall(new Vector3(0, 5, 248), new Vector3(260, 20, 2));
        Wall(new Vector3(-128, 5, 60), new Vector3(2, 20, 380));
        Wall(new Vector3(128, 5, 60), new Vector3(2, 20, 380));
        Wall(new Vector3(0, 5, -128), new Vector3(260, 20, 2));
    }

    Material Mat(Shader s, string n, Color c, float met = 0f, float sm = 0.4f)
    {
        var m = new Material(s); m.name = n; m.color = c;
        if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", met);
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", sm);
        return m;
    }
    static float Rand(System.Random r, float a, float b) => (float)(a + r.NextDouble() * (b - a));

    void Wall(Vector3 pos, Vector3 scale)
    {
        var w = GameObject.CreatePrimitive(PrimitiveType.Cube);
        w.name = "MapBounds";
        w.transform.SetParent(root, false);
        w.transform.position = pos;
        w.transform.localScale = scale;
        w.GetComponent<Renderer>().enabled = false;
        w.GetComponent<BoxCollider>().isTrigger = false;
    }

    // Ступенчатая гора: 4-5 цилиндров убывающего радиуса = естественные террасы для подъёма.
    void BuildSteppedMountain(Vector3 basePos, System.Random rng)
    {
        var m = new GameObject($"Mountain_{basePos.x}_{basePos.z}");
        m.transform.SetParent(root, false);
        m.transform.position = basePos;

        int tiers = 5;
        float r = Rand(rng, 18, 26);
        float y = 0;
        for (int t = 0; t < tiers; t++)
        {
            float h = Rand(rng, 6, 9);
            var tier = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            tier.name = $"Tier_{t}";
            tier.transform.SetParent(m.transform, false);
            tier.transform.localPosition = new Vector3(Rand(rng, -1.5f, 1.5f), y + h / 2f, Rand(rng, -1.5f, 1.5f));
            // Cylinder-примитив: радиус 0.5, поэтому scale.x/z = диаметр = r*2.
            tier.transform.localScale = new Vector3(r * 2f, h / 2f, r * 2f);
            tier.transform.rotation = Quaternion.Euler(0, Rand(rng, 0, 360), 0);
            tier.GetComponent<Renderer>().sharedMaterial = (t < 2) ? rock : rockDark;
            y += h * 0.82f; // небольшое перекрытие
            r *= Rand(rng, 0.72f, 0.8f);
        }
        // Снежная шапка
        var cap = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        cap.name = "SnowCap";
        cap.transform.SetParent(m.transform, false);
        cap.transform.localPosition = new Vector3(0, y + 1f, 0);
        cap.transform.localScale = new Vector3(r * 2.4f, r * 0.9f, r * 2.4f);
        cap.GetComponent<Renderer>().sharedMaterial = snow;

        // Лестница-уступы с одной стороны (4 платформы вверх по спирали)
        for (int i = 0; i < 4; i++)
        {
            float ang = i * 90f * Mathf.Deg2Rad;
            var ledge = GameObject.CreatePrimitive(PrimitiveType.Cube);
            ledge.name = $"Ledge_{i}";
            ledge.transform.SetParent(m.transform, false);
            ledge.transform.localPosition = new Vector3(Mathf.Cos(ang) * (14 - i * 2.5f), 4 + i * 6f, Mathf.Sin(ang) * (14 - i * 2.5f));
            ledge.transform.localScale = new Vector3(5, 0.8f, 5);
            ledge.GetComponent<Renderer>().sharedMaterial = rockDark;
            // Стена для карабканья рядом с уступом (имя содержит Climb — по нему детектим, тег не требуем)
            var cw = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cw.name = "ClimbWall";
            cw.transform.SetParent(m.transform, false);
            cw.transform.localPosition = ledge.transform.localPosition + new Vector3(0, 3f, 0);
            cw.transform.localScale = new Vector3(4, 6, 0.8f);
            cw.GetComponent<Renderer>().sharedMaterial = climbMat;
        }
    }

    // Гарантированная тропа: плоские уступы змейкой + оранжевые Climbable-стены.
    void BuildClimbTrail(Vector3 from, Vector3 to, System.Random rng)
    {
        var trail = new GameObject("ClimbTrail");
        trail.transform.SetParent(root, false);
        int steps = 12;
        for (int i = 0; i <= steps; i++)
        {
            float t = i / (float)steps;
            Vector3 p = Vector3.Lerp(from, to, t);
            p.x += Mathf.Sin(t * Mathf.PI * 3f) * 10f; // серпантин
            p.y = t * 30f; // плавный набор высоты
            var plat = GameObject.CreatePrimitive(PrimitiveType.Cube);
            plat.name = $"TrailStep_{i}";
            plat.transform.SetParent(trail.transform, false);
            plat.transform.position = p;
            plat.transform.localScale = new Vector3(4.5f, 0.7f, 4.5f);
            plat.GetComponent<Renderer>().sharedMaterial = rockDark;
            if (i < steps)
            {
                // Оранжевая стенка-подсказка между ступенями
                Vector3 np = Vector3.Lerp(from, to, (i + 1) / (float)steps);
                np.x += Mathf.Sin((t + 1f / steps) * Mathf.PI * 3f) * 10f;
                np.y = (t + 1f / steps) * 30f;
                Vector3 mid = (p + np) / 2f;
                var w = GameObject.CreatePrimitive(PrimitiveType.Cube);
                w.name = "ClimbWall";
                w.transform.SetParent(trail.transform, false);
                w.transform.position = mid;
                w.transform.localScale = new Vector3(3.5f, 5f, 0.8f);
                w.transform.rotation = Quaternion.Euler(0, Mathf.Atan2(np.x - p.x, np.z - p.z) * Mathf.Rad2Deg, 0);
                w.GetComponent<Renderer>().sharedMaterial = climbMat;
            }
        }
    }

    void BuildPine(Vector3 p, float s)
    {
        var pine = new GameObject("Pine");
        pine.transform.SetParent(root, false);
        pine.transform.position = new Vector3(p.x, 0, p.z);
        // Прижмём к земле: рейкаст вниз, иначе y=0
        RaycastHit hit;
        float y = 0;
        if (Physics.Raycast(new Vector3(p.x, 60, p.z), Vector3.down, out hit, 120))
            y = hit.point.y;
        pine.transform.position = new Vector3(p.x, y, p.z);
        pine.transform.rotation = Quaternion.Euler(0, Random.Range(0, 360), 0);

        var trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        trunk.transform.SetParent(pine.transform, false);
        trunk.transform.localPosition = new Vector3(0, 1.2f * s, 0);
        trunk.transform.localScale = new Vector3(0.5f * s, 1.2f * s, 0.5f * s);
        trunk.GetComponent<Renderer>().sharedMaterial = pineTrunk;

        for (int i = 0; i < 3; i++)
        {
            // Слои кроны — сплюснутые сферы
            var layer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            layer.transform.SetParent(pine.transform, false);
            layer.transform.localPosition = new Vector3(0, (2.2f + i * 1.1f) * s, 0);
            float rr = (2.4f - i * 0.6f) * s;
            layer.transform.localScale = new Vector3(rr, rr * 0.55f, rr);
            layer.GetComponent<Renderer>().sharedMaterial = pineLeaf;
            layer.GetComponent<SphereCollider>().enabled = false;
        }
    }

    void BuildSummit(Vector3 basePos)
    {
        var top = new GameObject("SummitCamp");
        top.transform.SetParent(root, false);
        top.transform.position = basePos + new Vector3(0, 33f, 0);
        var plat = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        plat.name = "SummitPlatform";
        plat.transform.SetParent(top.transform, false);
        plat.transform.localPosition = Vector3.zero;
        plat.transform.localScale = new Vector3(10, 0.8f, 10);
        plat.GetComponent<Renderer>().sharedMaterial = rockDark;
        // Флаг
        var pole = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        pole.transform.SetParent(top.transform, false);
        pole.transform.localPosition = new Vector3(0, 3.5f, 0);
        pole.transform.localScale = new Vector3(0.2f, 3.5f, 0.2f);
        pole.GetComponent<Renderer>().sharedMaterial = pineTrunk;
        var flag = GameObject.CreatePrimitive(PrimitiveType.Cube);
        flag.transform.SetParent(top.transform, false);
        flag.transform.localPosition = new Vector3(1.1f, 5.8f, 0);
        flag.transform.localScale = new Vector3(2.2f, 1.2f, 0.15f);
        var fs = Shader.Find("Universal Render Pipeline/Lit");
        if (fs == null) fs = Shader.Find("Standard");
        var fm = new Material(fs); fm.color = new Color(0.85f, 0.2f, 0.15f);
        flag.GetComponent<Renderer>().sharedMaterial = fm;
        flag.GetComponent<BoxCollider>().enabled = false;
        // Кострище-награда
        var fire = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        fire.transform.SetParent(top.transform, false);
        fire.transform.localPosition = new Vector3(-2.5f, 1f, 0);
        fire.transform.localScale = new Vector3(0.8f, 1.2f, 0.8f);
        var fms = Shader.Find("Universal Render Pipeline/Lit");
        if (fms == null) fms = Shader.Find("Standard");
        var fmm = new Material(fms); fmm.color = new Color(1f, 0.5f, 0.1f);
        fmm.EnableKeyword("_EMISSION");
        fmm.SetColor("_EmissionColor", new Color(1f, 0.5f, 0.1f) * 2f);
        fire.GetComponent<Renderer>().sharedMaterial = fmm;
        fire.GetComponent<SphereCollider>().enabled = false;
    }
}
