using UnityEngine;

// Снаряд плевка ламы. Зелёный шарик с Rigidbody, дамажит всё с IDamageable.
public class LlamaSpit : MonoBehaviour
{
    public int damage = 25;
    public float life = 3f;
    Rigidbody rb;

    public static LlamaSpit Fire(Vector3 pos, Vector3 dir, int dmg)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = "Spit";
        go.transform.position = pos;
        go.transform.localScale = Vector3.one * 0.35f;
        var s = Shader.Find("Universal Render Pipeline/Lit");
        if (s == null) s = Shader.Find("Standard");
        var m = new Material(s);
        m.color = new Color(0.4f, 0.8f, 0.3f);
        go.GetComponent<Renderer>().sharedMaterial = m;
        var col = go.GetComponent<SphereCollider>();
        col.isTrigger = true;
        col.radius = 0.6f;
        var rb = go.AddComponent<Rigidbody>();
        rb.useGravity = true;
        rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
        var spit = go.AddComponent<LlamaSpit>();
        spit.damage = dmg;
        rb.linearVelocity = dir.normalized * 18f + Vector3.up * 2f;
        Object.Destroy(go, spit.life);
        return spit;
    }

    void Awake() { rb = GetComponent<Rigidbody>(); }

    void OnTriggerEnter(Collider other)
    {
        if (other.transform.root != null && other.transform.root.GetComponentInChildren<PlayerController>() != null) return;
        if (other.GetComponentInParent<LlamaMount>() != null) return;
        var dmg = other.GetComponentInParent<IDamageable>();
        if (dmg != null) dmg.Damage(damage);
        // Маленький всплеск
        transform.localScale = Vector3.one * 0.6f;
        Destroy(gameObject, 0.08f);
    }
}
