using UnityEngine;

// Лама-маунт: на ней сидит игрок и едет (как в PEAK).
// Управление верхом: WASD движение, Shift галоп, Space прыжок.
// ЛКМ / Q — плевок из рта. E — сесть/слезть (обрабатывает PlayerController).
// Без всадника — пасётся: качает головой, ходит кругами.
[RequireComponent(typeof(CharacterController))]
public class LlamaMount : MonoBehaviour, IDamageable
{
    [Header("Скорость")]
    public float walkSpeed = 6f;
    public float gallopSpeed = 11f;
    public float jumpForce = 6.5f;
    public float gravity = -22f;
    public float turnSpeed = 10f;

    [Header("Плевок")]
    public int spitDamage = 25;
    public float spitCooldown = 0.8f;

    [HideInInspector] public PlayerController Rider;
    [HideInInspector] public Transform mountPoint;
    [HideInInspector] public Transform mouth;

    public int health = 120;

    CharacterController cc;
    Vector3 vel;
    float cd;
    float grazeT;
    Vector3 grazeDir = Vector3.forward;
    GameObject headPivot;
    Transform cam;

    void Awake()
    {
        cc = GetComponent<CharacterController>();
        cc.height = 1.6f; cc.radius = 0.55f; cc.center = new Vector3(0, 0.9f, 0);
        BuildModel();
    }

    void Start()
    {
        var c = Camera.main;
        if (c != null) cam = c.transform;
    }

    void Update()
    {
        cd -= Time.deltaTime;
        if (Rider != null)
        {
            if (cam == null) { var c = Camera.main; if (c != null) cam = c.transform; }
            float h = Input.GetAxisRaw("Horizontal");
            float v = Input.GetAxisRaw("Vertical");
            bool gallop = Input.GetKey(KeyCode.LeftShift);
            float speed = gallop ? gallopSpeed : walkSpeed;

            Vector3 fwd = cam != null ? cam.forward : transform.forward;
            fwd.y = 0; fwd.Normalize();
            Vector3 right = cam != null ? cam.right : Vector3.right;
            right.y = 0; right.Normalize();
            Vector3 move = right * h + fwd * v;
            if (move.sqrMagnitude > 1f) move.Normalize();

            if (cc.isGrounded)
            {
                if (vel.y < 0) vel.y = -2f;
                if (Input.GetKeyDown(KeyCode.Space)) vel.y = jumpForce;
            }
            vel.y += gravity * Time.deltaTime;
            cc.Move((move * speed + new Vector3(0, vel.y, 0)) * Time.deltaTime);
            if (move.sqrMagnitude > 0.05f)
            {
                Quaternion look = Quaternion.LookAtRotation(move);
                transform.rotation = Quaternion.Slerp(transform.rotation, look, Time.deltaTime * turnSpeed);
            }
            // Покачивание головы при беге
            if (headPivot != null)
                headPivot.transform.localRotation = Quaternion.Euler(Mathf.Sin(Time.time * 8f) * 4f, 0, 0);
            if ((Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Q)) && cd <= 0f)
                Spit();
        }
        else
        {
            // Пасётся рядом
            grazeT -= Time.deltaTime;
            if (grazeT <= 0f)
            {
                grazeT = Random.Range(2f, 5f);
                grazeDir = new Vector3(Random.Range(-1f, 1f), 0, Random.Range(-1f, 1f)).normalized;
            }
            if (cc.isGrounded) vel.y = -2f;
            vel.y += gravity * Time.deltaTime;
            Vector3 idle = grazeDir * 0.6f;
            // Не уходить далеко от спавна: держим радиус 12 от старта
            cc.Move((idle + new Vector3(0, vel.y, 0)) * Time.deltaTime);
            if (idle.sqrMagnitude > 0.01f)
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookAtRotation(idle), Time.deltaTime * 2f);
            if (headPivot != null)
                headPivot.transform.localRotation = Quaternion.Euler(18f + Mathf.Sin(Time.time * 1.5f) * 8f, 0, 0);
        }
    }

    public void Spit()
    {
        if (cd > 0f) return;
        cd = spitCooldown;
        Vector3 from = mouth != null ? mouth.position : transform.position + Vector3.up * 1.8f + transform.forward;
        LlamaSpit.Fire(from, transform.forward + Vector3.up * 0.12f, spitDamage);
        // Отдача шеи
        if (headPivot != null) headPivot.transform.localRotation = Quaternion.Euler(-18f, 0, 0);
    }

    public void Damage(int dmg)
    {
        health -= dmg;
        if (health <= 0)
        {
            health = 120;
            if (Rider != null) Rider.Dismount();
            var s = GameObject.Find("PlayerSpawn");
            transform.position = (s != null ? s.transform.position : Vector3.zero) + new Vector3(2, 2, 0);
        }
    }

    // ---------- Моделька из примитивов + физика ----------
    void BuildModel()
    {
        var s = Shader.Find("Universal Render Pipeline/Lit");
        if (s == null) s = Shader.Find("Standard");
        Material fur = new Material(s); fur.color = new Color(0.92f, 0.82f, 0.66f);
        Material furDark = new Material(s); furDark.color = new Color(0.78f, 0.64f, 0.45f);
        Material saddleMat = new Material(s); saddleMat.color = new Color(0.6f, 0.25f, 0.2f);
        Material dark = new Material(s); dark.color = Color.black;

        // Тело (горизонтальная капсула)
        var body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        body.name = "Body";
        body.transform.SetParent(transform, false);
        body.transform.localPosition = new Vector3(0, 1.25f, 0);
        body.transform.localRotation = Quaternion.Euler(90, 0, 0);
        body.transform.localScale = new Vector3(0.9f, 1.1f, 0.9f);
        body.GetComponent<Renderer>().sharedMaterial = fur;
        Destroy(body.GetComponent<Collider>()); // физика — CharacterController корня

        // Шея + голова (pivot для анимации)
        headPivot = new GameObject("NeckPivot");
        headPivot.transform.SetParent(transform, false);
        headPivot.transform.localPosition = new Vector3(0, 1.5f, 0.75f);

        var neck = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        neck.name = "Neck";
        neck.transform.SetParent(headPivot.transform, false);
        neck.transform.localPosition = new Vector3(0, 0.5f, 0.05f);
        neck.transform.localRotation = Quaternion.Euler(-12, 0, 0);
        neck.transform.localScale = new Vector3(0.42f, 0.7f, 0.42f);
        neck.GetComponent<Renderer>().sharedMaterial = fur;
        Destroy(neck.GetComponent<Collider>());

        var head = GameObject.CreatePrimitive(PrimitiveType.Cube);
        head.name = "Head";
        head.transform.SetParent(headPivot.transform, false);
        head.transform.localPosition = new Vector3(0, 1.05f, 0.2f);
        head.transform.localScale = new Vector3(0.38f, 0.42f, 0.7f);
        head.GetComponent<Renderer>().sharedMaterial = fur;
        Destroy(head.GetComponent<Collider>());

        // Морда
        var snout = GameObject.CreatePrimitive(PrimitiveType.Cube);
        snout.name = "Snout";
        snout.transform.SetParent(headPivot.transform, false);
        snout.transform.localPosition = new Vector3(0, 0.98f, 0.6f);
        snout.transform.localScale = new Vector3(0.28f, 0.28f, 0.25f);
        snout.GetComponent<Renderer>().sharedMaterial = furDark;
        Destroy(snout.GetComponent<Collider>());

        // Уши
        for (int i = -1; i <= 1; i += 2)
        {
            var ear = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            ear.name = "Ear";
            ear.transform.SetParent(headPivot.transform, false);
            ear.transform.localPosition = new Vector3(i * 0.14f, 1.32f, 0.1f);
            ear.transform.localScale = new Vector3(0.12f, 0.25f, 0.12f);
            ear.GetComponent<Renderer>().sharedMaterial = furDark;
            Destroy(ear.GetComponent<Collider>());
        }
        // Глаза
        for (int i = -1; i <= 1; i += 2)
        {
            var eye = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            eye.transform.SetParent(headPivot.transform, false);
            eye.transform.localPosition = new Vector3(i * 0.2f, 1.1f, 0.42f);
            eye.transform.localScale = Vector3.one * 0.09f;
            eye.GetComponent<Renderer>().sharedMaterial = dark;
            Destroy(eye.GetComponent<Collider>());
        }

        var mo = new GameObject("Mouth");
        mo.transform.SetParent(headPivot.transform, false);
        mo.transform.localPosition = new Vector3(0, 0.95f, 0.72f);
        mouth = mo.transform;

        // Ноги 4 шт
        Vector3[] legs = {
            new Vector3(-0.32f, 0, 0.55f), new Vector3(0.32f, 0, 0.55f),
            new Vector3(-0.32f, 0, -0.55f), new Vector3(0.32f, 0, -0.55f)
        };
        foreach (var lp in legs)
        {
            var leg = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            leg.name = "Leg";
            leg.transform.SetParent(transform, false);
            leg.transform.localPosition = new Vector3(lp.x, 0.55f, lp.z);
            leg.transform.localScale = new Vector3(0.28f, 0.55f, 0.28f);
            leg.GetComponent<Renderer>().sharedMaterial = furDark;
            Destroy(leg.GetComponent<Collider>());
        }

        // Хвост
        var tail = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        tail.name = "Tail";
        tail.transform.SetParent(transform, false);
        tail.transform.localPosition = new Vector3(0, 1.4f, -1.05f);
        tail.transform.localScale = new Vector3(0.22f, 0.22f, 0.5f);
        tail.GetComponent<Renderer>().sharedMaterial = furDark;
        Destroy(tail.GetComponent<Collider>());

        // Седло + точка посадки
        var saddle = GameObject.CreatePrimitive(PrimitiveType.Cube);
        saddle.name = "Saddle";
        saddle.transform.SetParent(transform, false);
        saddle.transform.localPosition = new Vector3(0, 1.85f, -0.1f);
        saddle.transform.localScale = new Vector3(0.85f, 0.22f, 0.9f);
        saddle.GetComponent<Renderer>().sharedMaterial = saddleMat;
        Destroy(saddle.GetComponent<Collider>());

        var mp = new GameObject("MountPoint");
        mp.transform.SetParent(transform, false);
        mp.transform.localPosition = new Vector3(0, 2.05f, -0.1f);
        mountPoint = mp.transform;
    }
}
