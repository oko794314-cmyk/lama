using UnityEngine;

// Данж для прохождения: вход-арка в пустыне -> телепорт в подземелье.
// Внутри: 3 комнаты + коридоры, факелы, 4 скарабея-врага, 3 сундука с лутом, босс-голем.
// Физика: у всех стен/пола BoxCollider, у врагов Rigidbody, у порталов Trigger.
// Лама внутрь не идёт — авто-спешивание у входа.
public class DungeonGenerator : MonoBehaviour
{
    [Header("Позиции")]
    public Vector3 entrancePos = new Vector3(60, 0, -70);
    public Vector3 innerOrigin = new Vector3(60, -16, -70);

    Transform root;
    Material stone, stoneDark, goldMat, woodMat, fireMat, enemyMat, bossMat;

    public void Generate(int seed = 4242)
    {
        var old = GameObject.Find("Dungeon_Root");
        if (old != null) DestroyImmediate(old);
        root = new GameObject("Dungeon_Root").transform;

        var s = Shader.Find("Universal Render Pipeline/Lit");
        if (s == null) s = Shader.Find("Standard");
        stone = NewMat(s, "DungeonStone", new Color(0.5f, 0.46f, 0.4f));
        stoneDark = NewMat(s, "DungeonDark", new Color(0.32f, 0.28f, 0.25f));
        goldMat = NewMat(s, "Gold", new Color(0.95f, 0.75f, 0.25f), 0.8f, 0.8f);
        woodMat = NewMat(s, "DungeonWood", new Color(0.4f, 0.26f, 0.14f));
        fireMat = NewMat(s, "Torch", new Color(1f, 0.5f, 0.12f));
        fireMat.EnableKeyword("_EMISSION");
        fireMat.SetColor("_EmissionColor", new Color(1f, 0.5f, 0.12f) * 2f);
        enemyMat = NewMat(s, "Scarab", new Color(0.45f, 0.15f, 0.35f));
        bossMat = NewMat(s, "Golem", new Color(0.3f, 0.3f, 0.34f));

        BuildEntrance();
        BuildInterior(seed);
    }

    Material NewMat(Shader s, string n, Color c, float met = 0f, float sm = 0.4f)
    {
        var m = new Material(s); m.name = n; m.color = c;
        if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", met);
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", sm);
        return m;
    }

    void Box(string name, Vector3 pos, Vector3 scale, Material m, Transform parent, bool collider = true)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name;
        go.transform.SetParent(parent, false);
        go.transform.position = pos;
        go.transform.localScale = scale;
        go.GetComponent<Renderer>().sharedMaterial = m;
        go.GetComponent<BoxCollider>().enabled = collider;
    }

    // ---------- Вход на поверхности ----------
    void BuildEntrance()
    {
        var e = new GameObject("DungeonEntrance");
        e.transform.SetParent(root, false);
        e.transform.position = entrancePos;

        // Площадка
        Box("Pad", entrancePos + new Vector3(0, 0.2f, 0), new Vector3(12, 0.4f, 12), stoneDark, e.transform);
        // Пилоны арки
        Box("Pylon_L", entrancePos + new Vector3(-3, 2.5f, 0), new Vector3(1.6f, 5f, 1.6f), stone, e.transform);
        Box("Pylon_R", entrancePos + new Vector3(3, 2.5f, 0), new Vector3(1.6f, 5f, 1.6f), stone, e.transform);
        Box("Lintel", entrancePos + new Vector3(0, 5.4f, 0), new Vector3(8.5f, 1.2f, 2f), stone, e.transform);
        // Череп-украшение
        var skull = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        skull.name = "SkullDeco";
        skull.transform.SetParent(e.transform, false);
        skull.transform.localPosition = new Vector3(0, 6.5f, 0);
        skull.transform.localScale = new Vector3(1.4f, 1f, 1.4f);
        skull.GetComponent<Renderer>().sharedMaterial = goldMat;

        // Лестница вниз (декор, 5 ступеней)
        for (int i = 0; i < 5; i++)
            Box($"Step_{i}", entrancePos + new Vector3(0, -0.4f - i * 0.55f, 2.5f + i * 1.1f), new Vector3(4, 0.5f, 1.2f), stoneDark, e.transform);

        // Факелы у входа
        for (int i = -1; i <= 1; i += 2)
            Torch(e.transform, entrancePos + new Vector3(i * 3f, 2.5f, 1.2f));

        // Табличка-подсказка
        var hint = new GameObject("Hint_Enter");
        hint.transform.SetParent(e.transform, false);
        hint.transform.position = entrancePos + new Vector3(0, 3f, 0);
        var hb = hint.AddComponent<BoxCollider>();
        hb.isTrigger = true; hb.size = new Vector3(6, 4, 6);
        var portal = hint.AddComponent<DungeonPortal>();
        portal.isEnter = true;
        portal.dungeon = this;

        // Имя над входом видно издалека: высокий обелиск
        Box("Obelisk", entrancePos + new Vector3(0, 4f, -6), new Vector3(1.2f, 12f, 1.2f), stoneDark, e.transform);
    }

    void Torch(Transform parent, Vector3 pos)
    {
        var t = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        t.name = "TorchStick";
        t.transform.SetParent(parent, false);
        t.transform.position = pos;
        t.transform.localScale = new Vector3(0.2f, 0.9f, 0.2f);
        t.GetComponent<Renderer>().sharedMaterial = woodMat;
        var f = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        f.name = "Flame";
        f.transform.SetParent(parent, false);
        f.transform.position = pos + Vector3.up * 1f;
        f.transform.localScale = new Vector3(0.5f, 0.8f, 0.5f);
        f.GetComponent<Renderer>().sharedMaterial = fireMat;
        f.GetComponent<SphereCollider>().enabled = false;
        var l = new GameObject("TorchLight");
        l.transform.SetParent(parent, false);
        l.transform.position = pos + Vector3.up * 1.2f;
        var pl = l.AddComponent<Light>();
        pl.type = LightType.Point; pl.color = new Color(1f, 0.6f, 0.25f);
        pl.intensity = 10f; pl.range = 16f;
    }

    // ---------- Подземелье ----------
    void BuildInterior(int seed)
    {
        var rng = new System.Random(seed);
        var inner = new GameObject("DungeonInterior");
        inner.transform.SetParent(root, false);
        inner.transform.position = innerOrigin;

        // Пол 46x34
        Box("Floor", innerOrigin, new Vector3(46, 1, 34), stoneDark, inner.transform);
        // Потолок (чтобы не было видно небо)
        Box("Ceil", innerOrigin + new Vector3(0, 6f, 0), new Vector3(46, 1, 34), stoneDark, inner.transform);
        // Стены периметра
        Box("Wall_N", innerOrigin + new Vector3(0, 3f, 17), new Vector3(46, 6, 1.5f), stone, inner.transform);
        Box("Wall_S", innerOrigin + new Vector3(0, 3f, -17), new Vector3(46, 6, 1.5f), stone, inner.transform);
        Box("Wall_W", innerOrigin + new Vector3(-23, 3f, 0), new Vector3(1.5f, 6, 34), stone, inner.transform);
        Box("Wall_E", innerOrigin + new Vector3(23, 3f, 0), new Vector3(1.5f, 6, 34), stone, inner.transform);

        // Перегородки: 2 стены с проходами (3 комнаты)
        // Стена 1 на x=-6, проход шириной 4 по центру
        Box("Div1_A", innerOrigin + new Vector3(-6, 3f, -10.5f), new Vector3(1.5f, 6, 13), stone, inner.transform);
        Box("Div1_B", innerOrigin + new Vector3(-6, 3f, 10.5f), new Vector3(1.5f, 6, 13), stone, inner.transform);
        Box("Div1_Top", innerOrigin + new Vector3(-6, 5.2f, 0), new Vector3(1.5f, 1.6f, 8), stone, inner.transform);
        // Стена 2 на x=9
        Box("Div2_A", innerOrigin + new Vector3(9, 3f, -10.5f), new Vector3(1.5f, 6, 13), stone, inner.transform);
        Box("Div2_B", innerOrigin + new Vector3(9, 3f, 10.5f), new Vector3(1.5f, 6, 13), stone, inner.transform);
        Box("Div2_Top", innerOrigin + new Vector3(9, 5.2f, 0), new Vector3(1.5f, 1.6f, 8), stone, inner.transform);

        // Колонны
        for (int ix = -1; ix <= 1; ix++)
            for (int iz = -1; iz <= 1; iz++)
            {
                if (ix == 0 && iz == 0) continue;
                Vector3 p = innerOrigin + new Vector3(ix * 14f, 2.5f, iz * 10f);
                var c = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                c.name = "Column";
                c.transform.SetParent(inner.transform, false);
                c.transform.position = p;
                c.transform.localScale = new Vector3(1.4f, 2.5f, 1.4f);
                c.GetComponent<Renderer>().sharedMaterial = stone;
            }

        // Свет: факелы по стенам + общий тусклый свет
        for (int i = -2; i <= 2; i++)
        {
            Torch(inner.transform, innerOrigin + new Vector3(i * 9f, 2.5f, -15.5f));
            Torch(inner.transform, innerOrigin + new Vector3(i * 9f, 2.5f, 15.5f));
        }
        var amb = new GameObject("DungeonAmbient");
        amb.transform.SetParent(inner.transform, false);
        amb.transform.position = innerOrigin + Vector3.up * 5f;
        var al = amb.AddComponent<Light>();
        al.type = LightType.Point; al.color = new Color(0.5f, 0.6f, 0.8f);
        al.intensity = 6f; al.range = 50f;

        // Спавн игрока внутри (комната 1)
        var sp = new GameObject("DungeonSpawn");
        sp.transform.SetParent(inner.transform, false);
        sp.transform.position = innerOrigin + new Vector3(-19, 2f, 0);

        // Выход-портал (комната 1, рядом со спавном)
        var exit = new GameObject("ExitPortal");
        exit.transform.SetParent(inner.transform, false);
        exit.transform.position = innerOrigin + new Vector3(-21, 2f, 5);
        var eb = exit.AddComponent<BoxCollider>();
        eb.isTrigger = true; eb.size = new Vector3(3, 3, 3);
        var ep = exit.AddComponent<DungeonPortal>();
        ep.isEnter = false; ep.dungeon = this;
        // Визуал выхода: светящаяся арка
        var eg = GameObject.CreatePrimitive(PrimitiveType.Cube);
        eg.name = "ExitGlow";
        eg.transform.SetParent(exit.transform, false);
        eg.transform.localPosition = Vector3.zero;
        eg.transform.localScale = new Vector3(2, 3, 0.5f);
        eg.GetComponent<Renderer>().sharedMaterial = fireMat;
        eg.GetComponent<BoxCollider>().enabled = false;

        // Враги: скарабеи в комнатах 2 и 3
        SpawnEnemy(inner.transform, innerOrigin + new Vector3(0, 1.2f, -6));
        SpawnEnemy(inner.transform, innerOrigin + new Vector3(1, 1.2f, 6));
        SpawnEnemy(inner.transform, innerOrigin + new Vector3(16, 1.2f, -5));
        // Босс-голем в дальней комнате
        SpawnBoss(inner.transform, innerOrigin + new Vector3(17, 1.5f, 6));

        // Сундуки: 1 в каждой комнате
        SpawnChest(inner.transform, innerOrigin + new Vector3(-19, 1f, -12), "Сено для ламы (+скорость)");
        SpawnChest(inner.transform, innerOrigin + new Vector3(0, 1f, 12), "Золото фараона");
        SpawnChest(inner.transform, innerOrigin + new Vector3(20, 1f, -12), "Сердце голема (победа!)");

        // Ловушка: качающиеся шипы в проходе (просто урон-триггер)
        var trap = new GameObject("SpikeTrap");
        trap.transform.SetParent(inner.transform, false);
        trap.transform.position = innerOrigin + new Vector3(-6, 1f, 0);
        var tb = trap.AddComponent<BoxCollider>();
        tb.isTrigger = true; tb.size = new Vector3(3, 2, 6);
        trap.AddComponent<SpikeTrap>();
        var spikes = GameObject.CreatePrimitive(PrimitiveType.Cube);
        spikes.name = "Spikes";
        spikes.transform.SetParent(trap.transform, false);
        spikes.transform.localPosition = new Vector3(0, -0.4f, 0);
        spikes.transform.localScale = new Vector3(2, 0.4f, 5);
        spikes.GetComponent<Renderer>().sharedMaterial = stoneDark;
        spikes.GetComponent<BoxCollider>().enabled = false;
    }

    void SpawnEnemy(Transform parent, Vector3 pos)
    {
        var go = new GameObject("Scarab");
        go.transform.SetParent(parent, false);
        go.transform.position = pos;
        var body = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        body.transform.SetParent(go.transform, false);
        body.transform.localPosition = Vector3.zero;
        body.transform.localScale = new Vector3(1.4f, 0.9f, 1.8f);
        body.GetComponent<Renderer>().sharedMaterial = enemyMat;
        var rb = go.AddComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.FreezeRotation;
        var col = go.AddComponent<SphereCollider>();
        col.radius = 0.9f;
        var e = go.AddComponent<DungeonEnemy>();
        e.bodyMat = enemyMat;
    }

    void SpawnBoss(Transform parent, Vector3 pos)
    {
        var go = new GameObject("GolemBoss");
        go.transform.SetParent(parent, false);
        go.transform.position = pos;
        var body = GameObject.CreatePrimitive(PrimitiveType.Cube);
        body.transform.SetParent(go.transform, false);
        body.transform.localPosition = new Vector3(0, 1f, 0);
        body.transform.localScale = new Vector3(2.2f, 3f, 2.2f);
        body.GetComponent<Renderer>().sharedMaterial = bossMat;
        var head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        head.transform.SetParent(go.transform, false);
        head.transform.localPosition = new Vector3(0, 3f, 0);
        head.transform.localScale = Vector3.one * 1.2f;
        head.GetComponent<Renderer>().sharedMaterial = goldMat;
        var rb = go.AddComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.FreezeRotation;
        rb.mass = 4f;
        var col = go.AddComponent<BoxCollider>();
        col.size = new Vector3(2.2f, 4f, 2.2f);
        col.center = new Vector3(0, 1.6f, 0);
        var e = go.AddComponent<DungeonEnemy>();
        e.health = 120; e.damage = 20; e.speed = 2.2f;
        e.isBoss = true;
    }

    void SpawnChest(Transform parent, Vector3 pos, string loot)
    {
        var go = new GameObject("Chest");
        go.transform.SetParent(parent, false);
        go.transform.position = pos;
        var baseBox = GameObject.CreatePrimitive(PrimitiveType.Cube);
        baseBox.transform.SetParent(go.transform, false);
        baseBox.transform.localPosition = Vector3.zero;
        baseBox.transform.localScale = new Vector3(1.6f, 0.9f, 1.1f);
        baseBox.GetComponent<Renderer>().sharedMaterial = woodMat;
        var lid = GameObject.CreatePrimitive(PrimitiveType.Cube);
        lid.name = "Lid";
        lid.transform.SetParent(go.transform, false);
        lid.transform.localPosition = new Vector3(0, 0.6f, 0);
        lid.transform.localScale = new Vector3(1.6f, 0.35f, 1.1f);
        lid.GetComponent<Renderer>().sharedMaterial = goldMat;
        var trig = go.AddComponent<BoxCollider>();
        trig.isTrigger = true; trig.size = new Vector3(2.6f, 2.2f, 2.2f);
        var ch = go.AddComponent<DungeonChest>();
        ch.lootName = loot;
    }
}

// Портал входа/выхода. Лама остаётся снаружи.
public class DungeonPortal : MonoBehaviour
{
    public bool isEnter = true;
    public DungeonGenerator dungeon;
    bool busy;

    void OnTriggerEnter(Collider other)
    {
        if (busy) return;
        var pc = other.GetComponentInParent<PlayerController>();
        if (pc == null) return;
        busy = true;
        if (isEnter)
        {
            if (pc.isRiding) pc.Dismount(); // ламу не тащим в данж
            var sp = GameObject.Find("DungeonSpawn");
            pc.transform.position = (sp != null ? sp.transform.position : dungeon.innerOrigin) + Vector3.up * 1f;
            DungeonHUD.Msg("Ты в данже! Зачисти комнаты, открой сундуки (E), вернись к оранжевому порталу.");
        }
        else
        {
            pc.transform.position = dungeon.entrancePos + new Vector3(0, 2f, -4f);
            DungeonHUD.Msg("Ты выбрался из данжа!");
        }
        Invoke(nameof(Unbusy), 1f);
    }
    void Unbusy() { busy = false; }
}

// Простой HUD-подсказки данжа.
public static class DungeonHUD
{
    static string msg = "";
    static float until;
    public static void Msg(string s) { msg = s; until = Time.realtimeSinceStartup + 5f; }
    public static void GUI()
    {
        if (Time.realtimeSinceStartup < until && msg != "")
        {
            var st = new GUIStyle(GUI.skin.box);
            st.fontSize = 15; st.alignment = TextAnchor.MiddleCenter;
            GUI.Box(new Rect(Screen.width / 2 - 320, 20, 640, 46), msg, st);
        }
    }
}

// Враг данжа: ползёт к игроку, бьёт в упор, умирает от плевков.
public class DungeonEnemy : MonoBehaviour, IDamageable
{
    public int health = 50;
    public int damage = 10;
    public float speed = 3f;
    public bool isBoss;
    public Material bodyMat;
    float atkCd;
    Transform target;

    void Update()
    {
        atkCd -= Time.deltaTime;
        if (target == null)
        {
            var pc = FindFirstObjectByType<PlayerController>();
            if (pc != null) target = pc.transform;
            else return;
        }
        // Только если игрок в данже (глубоко под землёй)
        if (target.position.y > -5f) return;
        float d = Vector3.Distance(transform.position, target.position);
        if (d < 30f && d > 1.6f)
        {
            Vector3 dir = (target.position - transform.position);
            dir.y = 0; dir.Normalize();
            transform.position += dir * speed * Time.deltaTime;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookAtRotation(dir), Time.deltaTime * 5f);
        }
        if (d < 2f && atkCd <= 0f)
        {
            atkCd = 1.2f;
            var pc = target.GetComponent<PlayerController>();
            if (pc != null) pc.Damage(damage);
            // Отскок
            transform.position += -transform.forward * 0.4f;
        }
        // Покачивание
        transform.position += Vector3.up * Mathf.Sin(Time.time * 6f) * 0.002f;
    }

    public void Damage(int dmg)
    {
        health -= dmg;
        // Вспышка
        if (health <= 0)
        {
            DungeonHUD.Msg(isBoss ? "ГОЛЕМ ПОВЕРЖЕН! Забери Сердце голема из сундука!" : "Скарабей раздавлен плевком!");
            Destroy(gameObject);
        }
    }

    void OnCollisionEnter(Collision c)
    {
        var spit = c.collider.GetComponent<LlamaSpit>();
        if (spit != null) Damage(spit.damage);
    }
}

// Сундук: подойди и нажми E.
public class DungeonChest : MonoBehaviour
{
    public string lootName = "лут";
    bool opened;
    Transform lid;
    void Start()
    {
        lid = transform.Find("Lid");
    }
    void Update()
    {
        if (opened) return;
        var pc = FindFirstObjectByType<PlayerController>();
        if (pc == null) return;
        if (Vector3.Distance(pc.transform.position, transform.position) < 3f && Input.GetKeyDown(KeyCode.E))
        {
            opened = true;
            if (lid != null) lid.localRotation = Quaternion.Euler(-110, 0, 0);
            DungeonHUD.Msg("Сундук: " + lootName + "!");
            // Бафф: если сено — ускоряем ламу
            if (lootName.Contains("Сено"))
            {
                var llama = FindFirstObjectByType<LlamaMount>();
                if (llama != null) { llama.walkSpeed += 2f; llama.gallopSpeed += 2f; }
            }
            if (lootName.Contains("Золото"))
            {
                pc.health = 100;
            }
        }
    }
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, 3f);
    }
}

// Шипы-ловушка в проходе.
public class SpikeTrap : MonoBehaviour
{
    float cd;
    void OnTriggerStay(Collider other)
    {
        if (cd > Time.time) return;
        var pc = other.GetComponentInParent<PlayerController>();
        if (pc != null) { pc.Damage(8); cd = Time.time + 1f; DungeonHUD.Msg("Осторожно, шипы!"); }
    }
}
