// Общий интерфейс урона для врагов данжа, игрока и ламы.
public interface IDamageable
{
    void Damage(int dmg);
}
